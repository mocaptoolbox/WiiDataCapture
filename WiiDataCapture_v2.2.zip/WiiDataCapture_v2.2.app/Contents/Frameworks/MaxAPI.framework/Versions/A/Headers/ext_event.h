#ifndef _EXT_EVENT_H_
#define _EXT_EVENT_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_EVENT_H_ */
